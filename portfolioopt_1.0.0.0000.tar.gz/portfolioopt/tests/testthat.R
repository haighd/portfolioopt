library(testthat)
library(portfolioopt)

test_check("portfolioopt")
